// Counting forever, exit with ctl-c

#include <stdio.h>

int main(void)
{
    int i = 1;
    while (true)
    {
        printf("%i, ah ah ah\n"   
    }
}
